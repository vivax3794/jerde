# jerde

Json parsing for humans

Docs at: <https://vivax3794.github.io/jerde/jerde/>